import { useState } from 'react';
import { Button } from './components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card';
import { Input } from './components/ui/input';
import { Label } from './components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select';
import { Textarea } from './components/ui/textarea';
import { Badge } from './components/ui/badge';
import { Separator } from './components/ui/separator';
import { Heart, MapPin, Clock, Gift, Bed, Phone, Mail } from 'lucide-react';

export default function App() {
  const [rsvpSubmitted, setRsvpSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    attendance: '',
    guests: '',
    dietary: '',
    message: ''
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleRSVPSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setRsvpSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-rose-50 via-white to-pink-50">
      {/* Hero Section */}
      <section className="relative py-20 px-4 text-center">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8">
            <Heart className="w-8 h-8 mx-auto mb-4 text-rose-400" />
            <p className="text-rose-600 tracking-wider uppercase mb-4">You're Invited</p>
          </div>
          
          <h1 className="text-6xl md:text-8xl mb-6 text-gray-800 font-light">
            Emma & James
          </h1>
          
          <div className="text-xl md:text-2xl text-gray-600 mb-8 space-y-2">
            <p>are getting married</p>
            <p className="text-3xl md:text-4xl text-rose-600 font-medium">
              June 15th, 2025
            </p>
          </div>
          
          <p className="text-lg text-gray-500 max-w-2xl mx-auto leading-relaxed">
            Join us as we celebrate our love and begin our journey as husband and wife. 
            Your presence would make our special day complete.
          </p>
        </div>
      </section>

      <Separator className="max-w-4xl mx-auto" />

      {/* Event Details */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl text-center mb-12 text-gray-800">Event Details</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {/* Ceremony */}
            <Card className="bg-white/80 backdrop-blur-sm border-rose-100">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-gray-800">Ceremony</CardTitle>
                <CardDescription className="text-lg">Where we say "I do"</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-rose-500" />
                  <span>4:00 PM</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-rose-500" />
                  <div>
                    <p>St. Mary's Chapel</p>
                    <p className="text-sm text-gray-600">123 Wedding Lane, Romantic City, RC 12345</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reception */}
            <Card className="bg-white/80 backdrop-blur-sm border-rose-100">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-gray-800">Reception</CardTitle>
                <CardDescription className="text-lg">Let's celebrate together</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-rose-500" />
                  <span>6:00 PM - 11:00 PM</span>
                </div>
                <div className="flex items-center gap-3">
                  <MapPin className="w-5 h-5 text-rose-500" />
                  <div>
                    <p>The Grand Ballroom</p>
                    <p className="text-sm text-gray-600">456 Celebration Ave, Romantic City, RC 12345</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* RSVP Section */}
      <section className="py-16 px-4 bg-rose-50/50">
        <div className="max-w-2xl mx-auto">
          <h2 className="text-4xl text-center mb-8 text-gray-800">RSVP</h2>
          <p className="text-center text-gray-600 mb-8">
            Please respond by May 1st, 2025
          </p>

          {rsvpSubmitted ? (
            <Card className="bg-white">
              <CardContent className="pt-6 text-center">
                <div className="mb-4">
                  <Heart className="w-12 h-12 mx-auto text-rose-500 mb-4" />
                  <h3 className="text-2xl text-gray-800 mb-2">Thank You!</h3>
                  <p className="text-gray-600">
                    We've received your RSVP and can't wait to celebrate with you!
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            <Card className="bg-white">
              <CardContent className="pt-6">
                <form onSubmit={handleRSVPSubmit} className="space-y-6">
                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="name">Full Name</Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => handleInputChange('name', e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => handleInputChange('email', e.target.value)}
                        required
                      />
                    </div>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="attendance">Will you attend?</Label>
                      <Select onValueChange={(value) => handleInputChange('attendance', value)} required>
                        <SelectTrigger>
                          <SelectValue placeholder="Please select" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="yes">Joyfully accepts</SelectItem>
                          <SelectItem value="no">Regretfully declines</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="guests">Number of guests</Label>
                      <Select onValueChange={(value) => handleInputChange('guests', value)} required>
                        <SelectTrigger>
                          <SelectValue placeholder="Select number" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="1">1 guest</SelectItem>
                          <SelectItem value="2">2 guests</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="dietary">Dietary restrictions</Label>
                    <Input
                      id="dietary"
                      value={formData.dietary}
                      onChange={(e) => handleInputChange('dietary', e.target.value)}
                      placeholder="Any allergies or dietary preferences?"
                    />
                  </div>

                  <div>
                    <Label htmlFor="message">Special message (optional)</Label>
                    <Textarea
                      id="message"
                      value={formData.message}
                      onChange={(e) => handleInputChange('message', e.target.value)}
                      placeholder="Share your excitement or well wishes!"
                      rows={3}
                    />
                  </div>

                  <Button type="submit" className="w-full bg-rose-600 hover:bg-rose-700">
                    Send RSVP
                  </Button>
                </form>
              </CardContent>
            </Card>
          )}
        </div>
      </section>

      {/* Additional Information */}
      <section className="py-16 px-4">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl text-center mb-12 text-gray-800">Additional Information</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {/* Accommodations */}
            <Card className="bg-white/80 backdrop-blur-sm border-rose-100">
              <CardHeader className="text-center">
                <Bed className="w-8 h-8 mx-auto mb-2 text-rose-500" />
                <CardTitle className="text-xl">Accommodations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div>
                  <h4 className="font-medium">The Romantic Inn</h4>
                  <p className="text-gray-600">Special rate: $150/night</p>
                  <p className="text-gray-600">Code: EMMAJAMES</p>
                </div>
                <div>
                  <h4 className="font-medium">City Center Hotel</h4>
                  <p className="text-gray-600">Special rate: $120/night</p>
                  <p className="text-gray-600">Code: WEDDING2025</p>
                </div>
              </CardContent>
            </Card>

            {/* Registry */}
            <Card className="bg-white/80 backdrop-blur-sm border-rose-100">
              <CardHeader className="text-center">
                <Gift className="w-8 h-8 mx-auto mb-2 text-rose-500" />
                <CardTitle className="text-xl">Registry</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <p className="text-gray-600 text-center">
                  Your presence is the greatest gift, but if you'd like to celebrate with us:
                </p>
                <div className="space-y-2">
                  <Badge variant="outline" className="block text-center">Williams Sonoma</Badge>
                  <Badge variant="outline" className="block text-center">Target</Badge>
                  <Badge variant="outline" className="block text-center">Amazon</Badge>
                </div>
              </CardContent>
            </Card>

            {/* Contact */}
            <Card className="bg-white/80 backdrop-blur-sm border-rose-100">
              <CardHeader className="text-center">
                <Phone className="w-8 h-8 mx-auto mb-2 text-rose-500" />
                <CardTitle className="text-xl">Questions?</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3 text-sm">
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <Mail className="w-4 h-4 text-rose-500" />
                    <span>wedding@emmajames.com</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Phone className="w-4 h-4 text-rose-500" />
                    <span>(555) 123-4567</span>
                  </div>
                </div>
                <p className="text-gray-600">
                  Maid of Honor: Sarah Johnson<br />
                  Best Man: Michael Davis
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 bg-rose-100/50 text-center">
        <div className="max-w-2xl mx-auto">
          <Heart className="w-6 h-6 mx-auto mb-4 text-rose-500" />
          <p className="text-gray-600 mb-2">
            "Love is not about how many days, months, or years you have been together.<br />
            Love is about how much you love each other every single day."
          </p>
          <p className="text-sm text-gray-500">
            Emma & James • June 15th, 2025
          </p>
        </div>
      </footer>
    </div>
  );
}